/*Kartero App Configuration*/

var krms_driver_config ={		
	'ApiUrl':"http://ec2-13-126-171-124.ap-south-1.compute.amazonaws.com/Inbound_Project/admin/api",		
	'DialogDefaultTitle':"Inbound",	
	'PushProjectID':"281792327024",	
	'APIHasKey':""
};
